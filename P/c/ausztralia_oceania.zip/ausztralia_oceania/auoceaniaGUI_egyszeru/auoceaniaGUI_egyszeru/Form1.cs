﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace auoceaniaGUI_egyszeru
{
    public partial class Form1 : Form
    {
        List<Auceania> lorszagok=new List<Auceania>();
        void adatbetoltes()
        {
            lorszagok.Clear();
            rtadatok.Clear();
            rtnepsurusegek.Clear();
            FileStream fs = new FileStream("ausztralia_oceania.txt",FileMode.Open);
            StreamReader sr = new StreamReader(fs);
            while(!sr.EndOfStream)
            {
                string sor=sr.ReadLine();
                Auceania a = new Auceania(sor);
                lorszagok.Add(a);
                rtadatok.Text = rtadatok.Text + sor + "\n";
                rtnepsurusegek.Text = rtnepsurusegek.Text + a.Nev + ": " + a.Nepsuruseg()+"\n";
            }
            sr.Close();
            fs.Close();
        }
        void statisztikaSzamitas()
        {
            int maxnepesseg = 0;
            int minteruletu = 0;
            double atlag = 0;
            for(int i = 0; i < lorszagok.Count; i++)
            {
                if (lorszagok[i].Lakossag > lorszagok[maxnepesseg].Lakossag)
                    maxnepesseg = i;
                if (lorszagok[i].Terulet < lorszagok[minteruletu].Terulet)
                    minteruletu = i;
                atlag = atlag + lorszagok[i].Nepsuruseg();
            }
            lbmaxsuruseg.Text = "Legnagyobb népességű ország: " + lorszagok[maxnepesseg].Nev;
            lbminorszag.Text = "Legkisebb ország: " + lorszagok[minteruletu].Nev;
            atlag = atlag / lorszagok.Count;
            atlag = Math.Round(atlag,4);
            lbatlagneps.Text = "Átlagos népsűrűség: " + atlag;
        }
        void nepSurusegSzamitas()
        {
            if(txlakossag.TextLength > 0 && txterulet.TextLength > 0)
            {
                double nepsuruseg = Convert.ToDouble(txlakossag.Text) / Convert.ToDouble(txterulet.Text);
                nepsuruseg = Math.Round(nepsuruseg,4);
                lbnepsuruseg.Text = "Népsűrűség [fő/km2]: " + nepsuruseg;
            }
            else
            {
                lbnepsuruseg.Text = "";
            }
        }
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            adatbetoltes();
            statisztikaSzamitas();
        }

        private void txterulet_TextChanged(object sender, EventArgs e)
        {
            if (txterulet.TextLength > 0)
            {
                try
                {
                    int szam = Convert.ToInt32(txterulet.Text);
                }
                catch
                {
                    MessageBox.Show("Egész számot adjon meg!", "HIBA", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txterulet.Clear();
                    txterulet.Focus();
                }
            }
            nepSurusegSzamitas();
        }
        private void txlakossag_TextChanged_1(object sender, EventArgs e)
        {
            if (txlakossag.TextLength > 0)
            {
                try
                {
                    int szam = Convert.ToInt32(txlakossag.Text);
                }
                catch
                {
                    MessageBox.Show("Egész számot adjon meg!", "HIBA", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txlakossag.Clear();
                    txlakossag.Focus();
                }
            }
            nepSurusegSzamitas();
        }

        private void btmentes_Click(object sender, EventArgs e)
        {
            if (txnev.TextLength == 0)
            {
                MessageBox.Show("Adja meg a terület nevég!", "Hiba!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txnev.Focus();
            }
            else if (txterulet.TextLength == 0)
            {
                MessageBox.Show("Adja meg a terület nevég!", "Hiba!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txnev.Focus();
            }
            else if (txterulet.TextLength == 0)
            {
                MessageBox.Show("Adja meg a terület nevég!", "Hiba!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txnev.Focus();
            }
            else
            {
                FileStream fs = new FileStream("ausztralia_oceania.txt", FileMode.Append);
                StreamWriter sw = new StreamWriter(fs);
                sw.WriteLine($"\n {txnev.Text};{txterulet.Text};{txlakossag.Text}");
                sw.Close();
                fs.Close();
                MessageBox.Show("Sikeres mentés", "Üzenet", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txnev.Clear();
                txterulet.Clear();
                txlakossag.Clear();
                adatbetoltes();
                statisztikaSzamitas();
            }
        }

        private void btkilepes_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
