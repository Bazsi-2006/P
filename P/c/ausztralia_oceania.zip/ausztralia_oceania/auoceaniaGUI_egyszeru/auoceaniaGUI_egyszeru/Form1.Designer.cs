﻿namespace auoceaniaGUI_egyszeru
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rtadatok = new System.Windows.Forms.RichTextBox();
            this.rtnepsurusegek = new System.Windows.Forms.RichTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lbnepsuruseg = new System.Windows.Forms.Label();
            this.txnev = new System.Windows.Forms.TextBox();
            this.txterulet = new System.Windows.Forms.TextBox();
            this.txlakossag = new System.Windows.Forms.TextBox();
            this.btmentes = new System.Windows.Forms.Button();
            this.btkilepes = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbatlagneps = new System.Windows.Forms.Label();
            this.lbminorszag = new System.Windows.Forms.Label();
            this.lbmaxsuruseg = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // rtadatok
            // 
            this.rtadatok.Location = new System.Drawing.Point(12, 34);
            this.rtadatok.Name = "rtadatok";
            this.rtadatok.Size = new System.Drawing.Size(278, 209);
            this.rtadatok.TabIndex = 0;
            this.rtadatok.Text = "";
            // 
            // rtnepsurusegek
            // 
            this.rtnepsurusegek.Location = new System.Drawing.Point(296, 35);
            this.rtnepsurusegek.Name = "rtnepsurusegek";
            this.rtnepsurusegek.Size = new System.Drawing.Size(211, 208);
            this.rtnepsurusegek.TabIndex = 1;
            this.rtnepsurusegek.Text = "";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Adatok:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(293, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(92, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Népsűrűségek:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(513, 39);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Terület neve:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(513, 75);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(93, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "Területe (km2):";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(513, 106);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(88, 13);
            this.label5.TabIndex = 6;
            this.label5.Text = "Lakosság (fő):";
            // 
            // lbnepsuruseg
            // 
            this.lbnepsuruseg.AutoSize = true;
            this.lbnepsuruseg.Location = new System.Drawing.Point(513, 144);
            this.lbnepsuruseg.Name = "lbnepsuruseg";
            this.lbnepsuruseg.Size = new System.Drawing.Size(41, 13);
            this.lbnepsuruseg.TabIndex = 7;
            this.lbnepsuruseg.Text = "label6";
            // 
            // txnev
            // 
            this.txnev.Location = new System.Drawing.Point(602, 32);
            this.txnev.Name = "txnev";
            this.txnev.Size = new System.Drawing.Size(134, 20);
            this.txnev.TabIndex = 8;
            // 
            // txterulet
            // 
            this.txterulet.Location = new System.Drawing.Point(602, 72);
            this.txterulet.Name = "txterulet";
            this.txterulet.Size = new System.Drawing.Size(100, 20);
            this.txterulet.TabIndex = 9;
            this.txterulet.TextChanged += new System.EventHandler(this.txterulet_TextChanged);
            // 
            // txlakossag
            // 
            this.txlakossag.Location = new System.Drawing.Point(602, 103);
            this.txlakossag.Name = "txlakossag";
            this.txlakossag.Size = new System.Drawing.Size(100, 20);
            this.txlakossag.TabIndex = 10;
            this.txlakossag.TextChanged += new System.EventHandler(this.txlakossag_TextChanged_1);
            // 
            // btmentes
            // 
            this.btmentes.Location = new System.Drawing.Point(646, 158);
            this.btmentes.Name = "btmentes";
            this.btmentes.Size = new System.Drawing.Size(75, 40);
            this.btmentes.TabIndex = 11;
            this.btmentes.Text = "Mentés";
            this.btmentes.UseVisualStyleBackColor = true;
            this.btmentes.Click += new System.EventHandler(this.btmentes_Click);
            // 
            // btkilepes
            // 
            this.btkilepes.Location = new System.Drawing.Point(646, 204);
            this.btkilepes.Name = "btkilepes";
            this.btkilepes.Size = new System.Drawing.Size(75, 39);
            this.btkilepes.TabIndex = 12;
            this.btkilepes.Text = "Kilépés";
            this.btkilepes.UseVisualStyleBackColor = true;
            this.btkilepes.Click += new System.EventHandler(this.btkilepes_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.panel1.Controls.Add(this.lbatlagneps);
            this.panel1.Controls.Add(this.lbminorszag);
            this.panel1.Controls.Add(this.lbmaxsuruseg);
            this.panel1.Location = new System.Drawing.Point(12, 249);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(709, 100);
            this.panel1.TabIndex = 13;
            // 
            // lbatlagneps
            // 
            this.lbatlagneps.AutoSize = true;
            this.lbatlagneps.Location = new System.Drawing.Point(23, 62);
            this.lbatlagneps.Name = "lbatlagneps";
            this.lbatlagneps.Size = new System.Drawing.Size(41, 13);
            this.lbatlagneps.TabIndex = 2;
            this.lbatlagneps.Text = "label9";
            // 
            // lbminorszag
            // 
            this.lbminorszag.AutoSize = true;
            this.lbminorszag.Location = new System.Drawing.Point(23, 37);
            this.lbminorszag.Name = "lbminorszag";
            this.lbminorszag.Size = new System.Drawing.Size(41, 13);
            this.lbminorszag.TabIndex = 1;
            this.lbminorszag.Text = "label8";
            // 
            // lbmaxsuruseg
            // 
            this.lbmaxsuruseg.AutoSize = true;
            this.lbmaxsuruseg.Location = new System.Drawing.Point(23, 12);
            this.lbmaxsuruseg.Name = "lbmaxsuruseg";
            this.lbmaxsuruseg.Size = new System.Drawing.Size(41, 13);
            this.lbmaxsuruseg.TabIndex = 0;
            this.lbmaxsuruseg.Text = "label7";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(739, 356);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btkilepes);
            this.Controls.Add(this.btmentes);
            this.Controls.Add(this.txlakossag);
            this.Controls.Add(this.txterulet);
            this.Controls.Add(this.txnev);
            this.Controls.Add(this.lbnepsuruseg);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.rtnepsurusegek);
            this.Controls.Add(this.rtadatok);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ausztrália és Óceánia";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox rtadatok;
        private System.Windows.Forms.RichTextBox rtnepsurusegek;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lbnepsuruseg;
        private System.Windows.Forms.TextBox txnev;
        private System.Windows.Forms.TextBox txterulet;
        private System.Windows.Forms.TextBox txlakossag;
        private System.Windows.Forms.Button btmentes;
        private System.Windows.Forms.Button btkilepes;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbatlagneps;
        private System.Windows.Forms.Label lbminorszag;
        private System.Windows.Forms.Label lbmaxsuruseg;
    }
}

